package Data_Structure;

import java.util.EmptyStackException;
import java.util.Iterator;

import Interface.BinarySearchTreeADT;

public class ArrayBinarySearchTree<T> extends ArraySearchTree<T> implements BinarySearchTreeADT<T>

{
    protected int height;
    protected int maxIndex;

    public ArrayBinarySearchTree()
    {
        super();
        height = 0;
        maxIndex = -1;
    }

    public ArrayBinarySearchTree (T element)
    {
        super(element);
        height = 1;
        maxIndex = 0;
    }

    public void addElement(T element) { 
    if (tree.length < maxIndex * 2 + 3) {
        expandCapacity();
    }
    
    Comparable<T> tempElement = (Comparable<T>) element;
    
    if (isEmpty()) { 
        tree[0] = element; 
        maxIndex = 0;
    } else { 
        boolean added = false; 
        int currentIndex = 0;
        
        while (!added) {
            if (tempElement.compareTo((tree[currentIndex])) < 0) {
                // go left
                if (tree[currentIndex * 2 + 1] == null) {
                    tree[currentIndex * 2 + 1] = element;
                    added = true;
                    if (currentIndex * 2 + 1 > maxIndex) {
                        maxIndex = currentIndex * 2 + 1;
                    }
                } else {
                    currentIndex = currentIndex * 2 + 1;
                }
            } else {
                // go right
                if (tree[currentIndex * 2 + 2] == null) {
                    tree[currentIndex * 2 + 2] = element;
                    added = true;
                    if (currentIndex * 2 + 2 > maxIndex) {
                        maxIndex = currentIndex * 2 + 2;
                    }
                } else {
                    currentIndex = currentIndex * 2 + 2;
                }
            }
        }
    }
    
    height = (int) (Math.log(maxIndex + 1) / Math.log(2)) + 1;
    count++;
} 
}
