package Data_Structure;

public class EmptyStackException extends Throwable {
    public EmptyStackException(String message) {
        super(message);
    }
}
