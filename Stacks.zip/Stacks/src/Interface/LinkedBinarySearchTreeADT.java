package Interface;

public class LinkedBinarySearchTreeADT {
    
}
