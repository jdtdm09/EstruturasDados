package Interface;

public interface OrderedListADT<T> extends ListADT<T> {

    public void add(T element);

}
