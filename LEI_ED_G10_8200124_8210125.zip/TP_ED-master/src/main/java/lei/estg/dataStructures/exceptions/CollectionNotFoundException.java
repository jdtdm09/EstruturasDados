package lei.estg.dataStructures.exceptions;

public class CollectionNotFoundException extends Throwable {

    public CollectionNotFoundException(String message) {
        super(message);
    }
}
