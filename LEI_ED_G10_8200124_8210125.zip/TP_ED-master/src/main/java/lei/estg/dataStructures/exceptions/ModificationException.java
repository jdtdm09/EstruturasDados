package lei.estg.dataStructures.exceptions;

public class ModificationException extends Throwable {
    public ModificationException(String message) {
        super(message);
    }
}
