package lei.estg.dataStructures.exceptions;

public class EmptyStackException extends Throwable {
    public EmptyStackException(String message) {
        super(message);
    }
}
