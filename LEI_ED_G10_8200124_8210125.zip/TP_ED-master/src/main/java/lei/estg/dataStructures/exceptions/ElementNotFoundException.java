package lei.estg.dataStructures.exceptions;

public class ElementNotFoundException extends Throwable {
    public ElementNotFoundException(String message) {
        super(message);
    }
}
