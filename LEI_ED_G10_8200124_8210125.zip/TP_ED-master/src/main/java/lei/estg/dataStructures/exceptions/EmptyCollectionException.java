package lei.estg.dataStructures.exceptions;

public class EmptyCollectionException extends Throwable {
    public EmptyCollectionException(String message) {
        super(message);
    }
}
