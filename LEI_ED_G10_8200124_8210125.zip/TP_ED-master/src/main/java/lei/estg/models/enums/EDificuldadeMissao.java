package lei.estg.models.enums;

public enum EDificuldadeMissao {
    FACIL,
    MEDIO,
    DIFICIL
}
